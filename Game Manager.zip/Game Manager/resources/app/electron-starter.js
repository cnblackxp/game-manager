const fs = require('fs');

createCollectionsFolder();
createConfigFile();


// Modules to control application life and create native browser window
const {app, BrowserWindow, Menu, ipcMain} = require('electron')

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let mainWindow, mainMenuu;




// setting basic events 
ipcMain.on('commit-games-list', (event, {profileFileName, gamesList}) => {
  console.log('commiting games list');
  fs.writeFileSync(`./collections/${checkExtensionAddIfNotAvailable(profileFileName)}`, JSON.stringify(gamesList));
  event.returnValue = '';
})

ipcMain.on('get-games-list', (event, profileFileName) => {
  console.log('getting games list');
  event.returnValue = getGamesList(profileFileName);
})

ipcMain.on('get-profiles-list', (event) => {
  console.log('getting profiles list');
  event.returnValue = getProfilesList();
})

ipcMain.on('delete-profile', (event, profileFileName) => {
  console.log('deleting profile');
  profileFileName = checkExtensionAddIfNotAvailable(profileFileName);
  fs.unlinkSync(`./collections/${profileFileName}`);
  const config = getConfigFile();
  if (config.defaultProfile === profileFileName) {
    updateConfigFile({
      ...config,
      defaultProfile: ""
    })
  }
  event.returnValue = '';
});

ipcMain.on('get-config', (event) => {
  console.log('getting config file');
  event.returnValue = getConfigFile();
});

ipcMain.on('commit-config', (event, config) => {
  console.log('commiting config file');
  updateConfigFile(config);
  event.returnValue = '';
});



function createWindow () {
  // Create the browser window.
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    webPreferences: {
      nodeIntegration: true
    }
  })

  // and load the index.html of the app.
  mainWindow.loadFile('build/index.html')
  // mainWindow.loadURL('http://localhost:3000')

  // Open the DevTools.
  // mainWindow.webContents.openDevTools()

  // Set Menu
  createMenu();

  // Emitted when the window is closed.
  mainWindow.on('closed', function () {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null;
    mainMenuu = null;
  })
}

function createMenu() {
  const menuTemplate = [
    {
      label: 'Profile',
      submenu: [
        {
          label: 'Switch Profile',
          click() {
            mainWindow.webContents.send('open-page', 'PROFILE_MANAGER');
          }
        }
      ]
    }
  ]

  mainMenuu = Menu.buildFromTemplate(menuTemplate);
  Menu.setApplicationMenu(mainMenuu);
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', createWindow)

// Quit when all windows are closed.
app.on('window-all-closed', function () {
  // On macOS it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') app.quit()
})

app.on('activate', function () {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (mainWindow === null) createWindow()
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.



/***************************************************************** */

function createCollectionsFolder() {
  if (!fs.existsSync('./collections')) {
    fs.mkdirSync('./collections');
  } else {
    console.log('collections exists');
  }
}

function createConfigFile() {
  if(!fs.existsSync('./config.json')) {
    const config = {
      defaultProfile: ''
    }
    fs.writeFileSync('./config.json', JSON.stringify(config));
  } else {
    console.log('config exists');
  }
}

function updateConfigFile(config) {
  fs.writeFileSync('./config.json', JSON.stringify(config));
}

function checkExtensionAddIfNotAvailable(fileName) {
  if (fileName.indexOf('.json') === -1) {
    return fileName + '.json';
  }
  return fileName;
}

function getGamesList(profileFileName) {
  const gamesListFileContent = fs.readFileSync(`./collections/${checkExtensionAddIfNotAvailable(profileFileName)}`);
  const gamesListStringified = gamesListFileContent.toString();
  const gamesList = JSON.parse(gamesListStringified);
  return gamesList;
}

function getProfilesList() {
  return fs.readdirSync('./collections').map(filePath => {
    const gamesList = getGamesList(filePath);
    return {
      profileFileName: filePath,
      gamesCount: gamesList.length
    }
  });
}

function getConfigFile() {
  const configFileContents = fs.readFileSync('./config.json');
  const configStringified= configFileContents.toString();
  const config = JSON.parse(configStringified);
  return config;
}